package choice;

public enum Choice {
        КАМЕНЬ,
        НОЖНИЦЫ,
        БУМАГА
}
