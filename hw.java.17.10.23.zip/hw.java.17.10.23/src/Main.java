import choice.Choice;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Добро пожаловать в игру - Камень, Ножницы, Бумага.");
        System.out.println("Введите Камень, Ножницы или Бумага");
        Scanner scr = new Scanner(System.in);
        String user = scr.nextLine();
        Choice userch = switch (user){
            case "Камень" -> Choice.КАМЕНЬ;
            case "Ножницы" -> Choice.НОЖНИЦЫ;
            case "Бумага" -> Choice.БУМАГА;
            default -> throw new RuntimeException("Вы ввели неверный вариант. Читайте условие.");
        };
        Random rnd = new Random();
        int prog = rnd.nextInt(Choice.values().length);
        Choice progch = Choice.values()[prog];
        System.out.println("Вы выбрали "+userch+". Программа выбрала "+progch);
        System.out.print(userch==progch ? "Ничья" : "");
        System.out.print(userch==Choice.КАМЕНЬ && progch==Choice.НОЖНИЦЫ || userch==Choice.НОЖНИЦЫ && progch==Choice.БУМАГА ||
                userch==Choice.БУМАГА && progch==Choice.КАМЕНЬ ? "Поздравляем Вы выйграли!" : "");
        System.out.print(userch==Choice.НОЖНИЦЫ && progch==Choice.КАМЕНЬ|| userch==Choice.БУМАГА && progch==Choice.НОЖНИЦЫ ||
                userch==Choice.КАМЕНЬ && progch==Choice.БУМАГА ? "Выйграла программа" : "");



    }
}
/*Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит свой выбор (в виде строки или числа).
Программа случайным образом делает свой выбор и выводит на экран.
Далее программа показывает, кто победитель – пользователь или программа.*/